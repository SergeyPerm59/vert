======================================================
Oracle Free Use Terms and Conditions (FUTC) License 
======================================================
https://www.oracle.com/downloads/licenses/oracle-free-license.html
===================================================================

ojdbc8-full.tar.gz - JDBC Thin Driver and Companion JARS
========================================================
This TAR archive (ojdbc8-full.tar.gz) contains the 21.5 release of the Oracle JDBC Thin driver(ojdbc8.jar), the Universal Connection Pool (ucp.jar) and other companion JARs grouped by category. 

(1) ojdbc8.jar (5,080,094 bytes) - 
(SHA1 Checksum: eb13f0948ca8675f71d59b5e8a1129d4c6189e7a)
Oracle JDBC Driver compatible with JDK8, JDK11, JDK12, JDK13, JDK14, and JDK15.
(2) ucp.jar (1,798,021 bytes) - (SHA1 Checksum: b9910cb21986a1a2635a3c082f05dc1ba47b2fa3)
Universal Connection Pool classes to be used with ojdbc8.jar -- for performance, scalability, high availability, sharded and multitenant databases.
(3) rsi.jar (345,038 bytes) - (SHA1 Checksum: 9f7af627459aad0b9aff37594eabfe37be4777b7)
Reactive Streams Ingestion (RSI) 
(4) ojdbc.policy (11,515 bytes) - Sample security policy file for Oracle Database JDBC drivers

======================
Security Related JARs
======================
Java applications require some additional jars to use Oracle Wallets. 
You need to use all the three jars while using Oracle Wallets. 

(5) oraclepki.jar (307,475 bytes) - (SHA1 Checksum: edeb1ecf18a165b9e217295808c5087059560187)
Additional jar required to access Oracle Wallets from Java
(6) osdt_cert.jar (210,835 bytes) - (SHA1 Checksum: dec25fb5d448ab65f3ba4f63e59038fb3eff9c0d)
Additional jar required to access Oracle Wallets from Java
(7) osdt_core.jar (312,754 bytes) - (SHA1 Checksum: 6dca3329ae25b77d924a1f32cacd2dbf9156f4de)
Additional jar required to access Oracle Wallets from Java

=============================
JARs for NLS and XDK support 
=============================
(8) orai18n.jar (1,664,456 bytes) - (SHA1 Checksum: a073ce669c94e444c45036c0e528eb03fb30a46e) 
Classes for NLS support
(9) xdb.jar (265,864 bytes) - (SHA1 Checksum: 9d8edfdd6e3440e634c1d6e6011affe76ae14efd)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(10) xmlparserv2.jar (1,953,724 bytes) - (SHA1 Checksum: 5cef860ff46da98cec070adc045fea5a75a2adc6)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(11) xmlparserv2_sans_jaxp_services.jar (1,948,954 bytes) - (SHA1 Checksum: 04a3a6fd600548355c43580fd7bb5c706c5b96ea) 
Classes to support standard JDBC 4.x java.sql.SQLXML interface

====================================================
JARs for Real Application Clusters(RAC), ADG, or DG 
====================================================
(12) ons.jar (198,457 bytes) - (SHA1 Checksum: d9b230dcf8405ba5d8dec90de9f1e409b70c9b83)
for use by the pure Java client-side Oracle Notification Services (ONS) daemon
(13) simplefan.jar (32,203 bytes) - (SHA1 Checksum: 5d3d5cabd75898e4251a6eed747a76a6aca98b45)
Java APIs for subscribing to RAC events via ONS; simplefan policy and javadoc


==================================================================================
NOTE: The diagnosability JARs **SHOULD NOT** be used in the production environment. 
These JARs (ojdbc8_g.jar,ojdbc8dms.jar, ojdbc8dms_g.jar) are meant to be used in the 
development, testing, or pre-production environment to diagnose any JDBC related issues. 

=====================================
OJDBC - Diagnosability Related JARs
===================================== 

(14) ojdbc8_g.jar (8,446,162 bytes) - (SHA1 Checksum: 9ad3ac2d7a806cd6d64db385c69b3994068aa6dc)
Same as ojdbc8.jar except compiled with "javac -g" and contains tracing code.

(15) ojdbc8dms.jar (7,048,053 bytes) - (SHA1 Checksum: 19f511b50ee939774f7a4802cfe876b82df6d1ce)
Same as ojdbc8.jar, except that it contains instrumentation to support DMS and limited java.util.logging calls.

(16) ojdbc8dms_g.jar (8,448,001 bytes) - (SHA1 Checksum: 952790dce9a3b0a411f66135c19d7bd81e9ad12b)
Same as ojdbc8_g.jar except that it contains instrumentation to support DMS.

(17) dms.jar (2,194,305 bytes) - (SHA1 Checksum: cd8f4b8325cad5281a8bab91fd2d29328d58b742)
dms.jar required for DMS-enabled JAR files.

==================================================================
Oracle JDBC and UCP - Javadoc and README
==================================================================

(18) JDBC-Javadoc-21c.jar (1,973,754 bytes) - JDBC API Reference 21c

(19) UCP-Javadoc-21c.jar (389,018 bytes) - UCP Java API Reference 21c

(20) RSI-Javadoc-21c.jar (425,701 bytes) - RSI Java API Reference 21c

(21) JDBC-Readme.txt: It contains general information about the JDBC driver and bugs that have been fixed in the 21.5 release. 

(22) UCP-Readme.txt: It contains general information about UCP and bugs that are fixed in the 21.5 release. 

(23) Bugs-fixed-in-215.txt: It contains the list of bugs fixed in the 21.5 release. 

=================
USAGE GUIDELINES
=================
Refer to the JDBC Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/21/jjdbc/index.html) and Universal Connection Pool Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/21/jjucp/index.html) for more details. 